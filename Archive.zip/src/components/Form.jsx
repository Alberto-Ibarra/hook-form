import React, {useState} from 'react'

const Form = () => {
    const [title, setTitle] = useState("first name")
    const [lastName, setLName] = useState("last name")
    const [email, setEmail] = useState("email")
    const [password, setPassword] = useState("password")
    const [confirmPassword, setCPassword] = useState("confirm password")
    return (
        <div>
            <h1>Form</h1>
            <form>
                <label> First Name: </label>
                <input name="title" type="text" onChange={(e)=>setTitle(e.target.value)} value={title} />
                <label> Last Name: </label>
                <input name="lastName" type="text" onChange={(e)=>setLName(e.target.value)} value={lastName} />
                <label> Email: </label>
                <input name="email" type="text" onChange={(e)=>setEmail(e.target.value)} value={email} />
                <label> Password: </label>
                <input name="password" type="text" onChange={(e)=>setPassword(e.target.value)} value={password} />
                <label> Confirm Password: </label>
                <input name="confirmPassword" type="text" onChange={(e)=>setCPassword(e.target.value)} value={confirmPassword} />
            </form>
            <p> First Name: {title}</p>
            <p> Last Name: {lastName}</p>
            <p> Email: {email}</p>
            <p> Password: {password}</p>
            <p> Confirm Password: {confirmPassword}</p>
        </div>
    )
}

export default Form